const mongoose = require('mongoose');

const ownerMaterialSchema = new mongoose.Schema({
    materialName: { type: String, required: true },
    siteName: { type: String, required: true },
    pricePerUnit: { type: Number, required: true },
    status: { type: String, default: 'active' }
});

const OwnerMaterial = mongoose.model('OwnerMaterial', ownerMaterialSchema);
module.exports = OwnerMaterial;
