const mongoose = require('mongoose');

const materialSchema = new mongoose.Schema({
    name: { type: String, required: true },
    pricePerUnit: { type: Number, required: true },
    status: { type: String, default: 'active' }
});

const Material = mongoose.model('Material', materialSchema);
module.exports = Material;
