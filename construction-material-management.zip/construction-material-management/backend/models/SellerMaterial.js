const mongoose = require('mongoose');

const sellerMaterialSchema = new mongoose.Schema({
    name: { type: String, required: true },
    pricePerUnit: { type: Number, required: true },
    status: { type: String, default: 'active' }
});

const SellerMaterial = mongoose.model('SellerMaterial', sellerMaterialSchema);
module.exports = SellerMaterial;
