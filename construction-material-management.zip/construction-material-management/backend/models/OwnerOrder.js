const mongoose = require('mongoose');

const ownerOrderSchema = new mongoose.Schema({
    materialName: { type: String, required: true },
    siteCode: { type: String, required: true },
    location: { type: String, required: true },
    supervisorName: { type: String, required: true },
    unitNeeded: { type: Number, required: true },
    status: { type: String, required: true, enum: ['Pending', 'Accepted', 'Rejected', 'Received', 'Completed'] },
    description: String,
    expenses: Number,
    image: String,
    amount: Number,
    sellerName: String
});

const OwnerOrder = mongoose.model('OwnerOrder', ownerOrderSchema);
module.exports = OwnerOrder;
