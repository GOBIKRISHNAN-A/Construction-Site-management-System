const express = require('express');
const ownerController = require('../controllers/ownerController');
const router = express.Router();

router.get('/dashboard', ownerController.getDashboard);
router.post('/review-orders', ownerController.reviewOrders);
router.post('/order-material', ownerController.orderMaterial);
router.get('/view-orders', ownerController.viewOrders);
router.post('/add-material', ownerController.addMaterial);
router.post('/manage-user', ownerController.manageUser);

module.exports = router;
