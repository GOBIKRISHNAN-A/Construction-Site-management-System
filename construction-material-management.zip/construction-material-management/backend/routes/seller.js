const express = require('express');
const sellerController = require('../controllers/sellerController');
const router = express.Router();

router.get('/dashboard', sellerController.getDashboard);
router.post('/manage-materials', sellerController.manageMaterials);
router.post('/review-orders', sellerController.reviewOrders);
router.get('/view-orders', sellerController.viewOrders);

module.exports = router;
