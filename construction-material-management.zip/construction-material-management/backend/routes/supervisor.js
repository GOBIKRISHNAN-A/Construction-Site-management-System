const express = require('express');
const supervisorController = require('../controllers/supervisorController');
const router = express.Router();

router.get('/dashboard', supervisorController.getDashboard);
router.post('/order', supervisorController.orderMaterial);
router.post('/update-status', supervisorController.updateStatus);
router.get('/view-orders', supervisorController.viewOrders);

module.exports = router;
