const session = require('express-session');
app.use(session({
    secret: 'mySecret',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 } // Session will expire after 60 seconds
}));
