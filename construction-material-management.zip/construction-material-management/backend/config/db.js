const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/cons_test', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log('MongoDB connected successfully.');
}).catch((err) => {
    console.log('MongoDB connection error:', err);
});
