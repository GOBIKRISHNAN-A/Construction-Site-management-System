const SellerMaterial = require('../models/SellerMaterial');
const OwnerOrder = require('../models/OwnerOrder');

exports.getDashboard = (req, res) => {
    res.sendFile('SellerDashboard.html', { root: './frontend/pages' });
};

exports.manageMaterials = async (req, res) => {
    const { name, pricePerUnit, status, materialId, action } = req.body;
    if (action === 'create') {
        const newMaterial = new SellerMaterial({ name, pricePerUnit, status });
        await newMaterial.save();
        res.json({ message: 'Material created successfully' });
    } else if (action === 'update') {
        await SellerMaterial.findByIdAndUpdate(materialId, { name, pricePerUnit, status });
        res.json({ message: 'Material updated successfully' });
    } else if (action === 'delete') {
        await SellerMaterial.findByIdAndDelete(materialId);
        res.json({ message: 'Material deleted successfully' });
    } else {
        res.status(400).json({ message: 'Invalid action' });
    }
};

exports.reviewOrders = async (req, res) => {
    const orders = await OwnerOrder.find({ status: 'Ordered' }); // Fetch orders made by Owner
    res.json(orders);
};

exports.viewOrders = async (req, res) => {
    const orders = await OwnerOrder.find({ sellerName: req.session.user.userId });
    res.json(orders);
};
