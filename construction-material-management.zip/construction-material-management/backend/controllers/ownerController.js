const OwnerOrder = require('../models/OwnerOrder');
const SupervisorOrder = require('../models/SupervisorOrder');
const OwnerMaterial = require('../models/OwnerMaterial');
const SellerMaterial = require('../models/SellerMaterial');
const User = require('../models/User');

exports.getDashboard = (req, res) => {
    res.sendFile('OwnerDashboard.html', { root: './frontend/pages' });
};

exports.reviewOrders = async (req, res) => {
    const orders = await SupervisorOrder.find({}); // Fetch all supervisor orders
    res.json(orders);
};

exports.orderMaterial = async (req, res) => {
    const { materialId, orderId, units, sellerName } = req.body;
    const material = await SellerMaterial.findById(materialId);
    const order = await SupervisorOrder.findById(orderId);

    if (material && order) {
        const newOrder = new OwnerOrder({
            materialName: material.name,
            siteCode: order.siteCode,
            location: order.location,
            supervisorName: order.supervisorName,
            unitNeeded: units,
            status: 'Ordered',
            amount: material.pricePerUnit * units,
            sellerName: sellerName
        });
        await newOrder.save();
        res.json({ message: 'Order placed successfully' });
    } else {
        res.status(400).json({ message: 'Invalid material or order' });
    }
};

exports.viewOrders = async (req, res) => {
    const { role } = req.query;
    let orders;

    if (role === 'supervisor') {
        orders = await SupervisorOrder.find({ supervisorName: req.session.user.userId });
    } else if (role === 'seller') {
        orders = await OwnerOrder.find({ sellerName: req.session.user.userId });
    } else {
        orders = await OwnerOrder.find({});
    }

    res.json(orders);
};

exports.addMaterial = async (req, res) => {
    const { name, siteName, pricePerUnit } = req.body;
    const newMaterial = new OwnerMaterial({ name, siteName, pricePerUnit });
    await newMaterial.save();
    res.json({ message: 'Material added successfully' });
};

exports.manageUser = async (req, res) => {
    const { userId, number, password, role, action } = req.body;
    if (action === 'create') {
        const newUser = new User({ userId, number, password, role });
        await newUser.save();
        res.json({ message: 'User created successfully' });
    } else if (action === 'delete') {
        await User.findOneAndDelete({ userId });
        res.json({ message: 'User deleted successfully' });
    } else if (action === 'update') {
        await User.findOneAndUpdate({ userId }, { number, password, role });
        res.json({ message: 'User updated successfully' });
    } else {
        res.status(400).json({ message: 'Invalid action' });
    }
};
