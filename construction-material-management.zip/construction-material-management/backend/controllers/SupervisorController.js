const SupervisorOrder = require('../models/SupervisorOrder');
const OwnerMaterial = require('../models/OwnerMaterial');

exports.getDashboard = (req, res) => {
    res.sendFile('SupervisorDashboard.html', { root: './frontend/pages' });
};

exports.orderMaterial = async (req, res) => {
    const { materialName, siteCode, location, unitNeeded } = req.body;
    const newOrder = new SupervisorOrder({
        materialName,
        siteCode,
        location,
        supervisorName: req.session.user.userId,
        unitNeeded,
        status: 'Pending'
    });
    await newOrder.save();
    res.json({ message: 'Order placed successfully' });
};

exports.updateStatus = async (req, res) => {
    const { orderId, status, description, expenses, image } = req.body;
    const order = await SupervisorOrder.findById(orderId);

    if (order) {
        order.status = status;
        order.description = description;
        order.expenses = expenses;
        order.image = image;
        await order.save();
        res.json({ message: 'Order status updated successfully' });
    } else {
        res.status(400).json({ message: 'Order not found' });
    }
};

exports.viewOrders = async (req, res) => {
    const orders = await SupervisorOrder.find({ supervisorName: req.session.user.userId });
    res.json(orders);
};
