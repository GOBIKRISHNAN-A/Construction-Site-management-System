const User = require('../models/User');
const bcrypt = require('bcryptjs');

exports.getLogin = (req, res) => {
    res.sendFile('Login.html', { root: './frontend/pages' });
};

exports.postLogin = async (req, res) => {
    const { userId, password } = req.body;
    const user = await User.findOne({ userId });

    if (user && await bcrypt.compare(password, user.password)) {
        req.session.user = user;
        if (user.role === 'OWNER') return res.redirect('/owner/dashboard');
        if (user.role === 'SUPERVISOR') return res.redirect('/supervisor/dashboard');
        if (user.role === 'SELLER') return res.redirect('/seller/dashboard');
    } else {
        res.redirect('/auth/login');
    }
};

exports.getRegister = (req, res) => {
    res.sendFile('Register.html', { root: './frontend/pages' });
};

exports.postRegister = async (req, res) => {
    const { userId, number, password, role } = req.body;
    if (role === 'SELLER') {
        const newUser = new User({ userId, number, password, role });
        await newUser.save();
        res.redirect('/auth/login');
    } else {
        res.redirect('/auth/register');
    }
};
