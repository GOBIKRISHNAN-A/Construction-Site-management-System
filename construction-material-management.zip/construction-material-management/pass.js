const bcrypt = require('bcryptjs');

const passwords = ["12345", "12345"]; // Replace with actual passwords

passwords.forEach(async (password) => {
    const hashedPassword = await bcrypt.hash(password, 10);
    console.log(hashedPassword);
});
