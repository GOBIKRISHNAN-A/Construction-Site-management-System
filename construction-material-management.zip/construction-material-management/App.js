const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
require('./backend/config/db'); // Ensure this line correctly points to the db.js file

const authRoutes = require('./backend/routes/auth');
const ownerRoutes = require('./backend/routes/owner');
const supervisorRoutes = require('./backend/routes/supervisor');
const sellerRoutes = require('./backend/routes/seller');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({ secret: 'mySecret', resave: false, saveUninitialized: true }));
app.use(express.static('frontend'));

// Route to serve the home page
app.get('/', (req, res) => {
    res.sendFile('Login.html', { root: './frontend/pages' });
});

app.use('/auth', authRoutes);
app.use('/owner', ownerRoutes);
app.use('/supervisor', supervisorRoutes);
app.use('/seller', sellerRoutes);

app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});
