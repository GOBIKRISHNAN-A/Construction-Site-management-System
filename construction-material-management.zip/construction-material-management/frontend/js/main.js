document.addEventListener('DOMContentLoaded', function () {
    // Fetch and populate materials for ordering (Owner)
    fetch('/owner/materials')
        .then(response => response.json())
        .then(data => {
            const materialSelect = document.getElementById('materialId');
            data.materials.forEach(material => {
                const option = document.createElement('option');
                option.value = material._id;
                option.textContent = `${material.name} - ₹${material.pricePerUnit}`;
                materialSelect.appendChild(option);
            });
        });

    // Fetch and populate supervisor orders for selecting (Owner)
    fetch('/owner/supervisor-orders')
        .then(response => response.json())
        .then(data => {
            const orderSelect = document.getElementById('orderId');
            data.orders.forEach(order => {
                const option = document.createElement('option');
                option.value = order._id;
                option.textContent = `Order #${order._id} - ${order.materialName}`;
                orderSelect.appendChild(option);
            });
        });

    // Fetch and populate orders for review (Owner)
    fetch('/owner/orders')
        .then(response => response.json())
        .then(data => {
            const ordersTable = document.getElementById('review-orders-table');
            data.orders.forEach(order => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${order.materialName}</td>
                    <td>${order.siteCode}</td>
                    <td>${order.location}</td>
                    <td>${order.supervisorName}</td>
                    <td>${order.unitNeeded}</td>
                    <td>
                        <button class="btn btn-success">Accept</button>
                        <button class="btn btn-danger">Reject</button>
                        <button class="btn btn-warning">Edit</button>
                    </td>
                `;
                ordersTable.appendChild(row);
            });
        });

    // Fetch and populate orders for viewing (Owner)
    fetch('/owner/view-orders')
        .then(response => response.json())
        .then(data => {
            const viewOrdersTable = document.getElementById('view-orders-table');
            data.orders.forEach(order => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${order._id}</td>
                    <td>${order.materialName}</td>
                    <td>${order.siteCode}</td>
                    <td>${order.location}</td>
                    <td>${order.supervisorName}</td>
                    <td>${order.status}</td>
                    <td>
                        <button class="btn btn-info">View</button>
                    </td>
                `;
                viewOrdersTable.appendChild(row);
            });
        });

    // Order Material (Supervisor)
    const orderMaterialForm = document.getElementById('order-material-form');
    orderMaterialForm.addEventListener('submit', function (event) {
        event.preventDefault();

        const formData = new FormData(orderMaterialForm);
        fetch('/supervisor/order', {
            method: 'POST',
            body: formData
        }).then(response => response.json())
          .then(data => alert(data.message))
          .catch(error => console.error('Error:', error));
    });

    // Update Status (Supervisor)
    const updateStatusForm = document.getElementById('update-status-form');
    updateStatusForm.addEventListener('submit', function (event) {
        event.preventDefault();

        const formData = new FormData(updateStatusForm);
        fetch('/supervisor/update-status', {
            method: 'POST',
            body: formData
        }).then(response => response.json())
          .then(data => alert(data.message))
          .catch(error => console.error('Error:', error));
    });

    // Fetch and populate orders (Supervisor)
    fetch('/supervisor/orders')
        .then(response => response.json())
        .then(data => {
            const ordersTable = document.getElementById('view-orders-table');
            data.orders.forEach(order => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${order._id}</td>
                    <td>${order.materialName}</td>
                    <td>${order.siteCode}</td>
                    <td>${order.location}</td>
                    <td>${order.supervisorName}</td>
                    <td>${order.status}</td>
                `;
                ordersTable.appendChild(row);
            });
        })
        .catch(error => console.error('Error:', error));

    // Manage Materials (Seller)
    const manageMaterialsForm = document.getElementById('manage-materials-form');
    manageMaterialsForm.addEventListener('submit', function (event) {
        event.preventDefault();
        const formData = new FormData(manageMaterialsForm);
        fetch('/seller/manage-materials', {
            method: 'POST',
            body: formData
        }).then(response => response.json())
          .then(data => alert(data.message))
          .catch(error => console.error('Error:', error));
    });
    
    // Fetch and populate orders for review (Seller)
    fetch('/seller/review-orders')
        .then(response => response.json())
        .then(data => {
            const ordersTable = document.getElementById('review-orders-table');
            data.orders.forEach(order => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${order._id}</td>
                    <td>${order.materialName}</td>
                    <td>${order.siteCode}</td>
                    <td>${order.location}</td>
                    <td>${order.unitNeeded}</td>
                    <td>
                        <button class="btn btn-success">Accept</button>
                        <button class="btn btn-danger">Reject</button>
                    </td>
                `;
                ordersTable.appendChild(row);
            });
        })
        .catch(error => console.error('Error:', error));
    
    // Fetch and populate orders for viewing (Seller)
    fetch('/seller/view-orders')
        .then(response => response.json())
        .then(data => {
            const viewOrdersTable = document.getElementById('view-orders-table');
            data.orders.forEach(order => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${order._id}</td>
                    <td>${order.materialName}</td>
                    <td>${order.siteCode}</td>
                    <td>${order.location}</td>
                    <td>${order.supervisorName}</td>
                    <td>${order.status}</td>
                `;
                viewOrdersTable.appendChild(row);
            });
        })
        .catch(error => console.error('Error:', error));
    });
    